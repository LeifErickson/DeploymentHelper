WINMERGE

WinMerge � um utilit�rio de c�digo fonte aberto para a compara��o e uni�o 
de ficheiros, execut�vel em todas as vers�es modernas do windows. Algumas 
fun��es requerem instala��es ou componentes adicionais. 

A �ltima vers�o do WinMerge como outras informa��es adicionais est�o dispon�veis em 
http://winmerge.org

Guia de utiliza��o r�pida do WinMerge: 
Leia atentamente o guia de utiliza��o r�pida do WinMerge dispon�vel online para iniciar o WinMerge:
http://manual.winmerge.org/QuickStart.html

Manual em HTML: O manual est� dispon�vel online em: 
http://manual.winmerge.org/ 
Possivelmente tamb�m est� instalado (se escolhido assim) localmente e 
transferido separadamente de http://winmerge.org/ (veja a documenta��o) 

Suporte para ficheiros:
WinMerge utiliza o 7-Zip para o suporte de ficheiros compactados. 7-Zip (http://www.7-zip.org) � uma utilit�rio de c�digo aberto para compress�o de ficheiros. 
Para instalar o suporte de ficheiros compactados, transfira o 7-Zip de http://winmerge.org/ 

Instala��o para suporte de ficheiros: 
� recomendado instalar o 7-Zip. Se por alguma raz�o n�o puder ser instalado, 
o configurador do 7-Zip pode instalar apenas os ficheiros necess�rios 
para ativar o suporte para ficheiros compactados. Tenha em conta que n�o � permitida a utiliza��o 
isolada do 7-Zip, apenas � habilitado o suporte para ficheiros de WinMerge.

Suporte de Scripts:
Se deseja trabalhar com scripts � necess�rio ter o Windows Scripting Host instalado. 
Se tiver ou receber quaisquer erros relacionados com os seus scripts, por favor visite 
http://msdn.microsoft.com/library/default.asp?url=/downloads/list/webdev.asp
para ter a certeza que o Scripting Host est� atualizado e n�o corrompido. 

Suporte:
Os programadores est�o a responder �s quest�es nos f�runs do WinMerge em Sourceforge.net:
http://sourceforge.net/forum/?group_id=13216
 
Erros e pedidos de novos recursos: 
Erros e pedidos de novos recursos devem ser enviados para a lista de erros e solicita��es (RFE) em sourceforge.net.
 
Lista de registo de erros (Bug tracker):
http://sourceforge.net/tracker/?group_id=13216&atid=113216 
Ao ser reportado um erro, por favor indique-nos a vers�o do WinMerge! 
As vers�es do WinMerge 2.2.0 e posteriores podem criar um registo das configura��es no menu Ajuda/Configura��es. 
Por favor, anexe o registo de configura��es (como anexo de ficheiro) ao relat�rio de erros.

Pedidos de novos recursos (RFE tracker):
http://sourceforge.net/tracker/?group_id=13216&atid=363216

- A equipa do WinMerge!
